export interface oneway{
    flightId: number;
    fromPlace : string;
    toPlace  :string;
    startDateTime  :Date; 
    endDateTime  :Date;
    flightNumber :string;
    scheduleDayOfWeek  : string;
    noOfBusinessClassSeat  :number;
    noOfNonBusinessClassSeat  :number;
    flightBusinessClassTicketPrice  :number;
    flightNonBusinessClassTicketPrice  :number;
    meal :string;
    indicator : boolean;
    airlineId :number;
}