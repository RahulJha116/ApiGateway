import { Component, OnInit } from '@angular/core';
import { AdminLoginService } from '../adminlogin.service';
import { IViewairline } from '../IViewairline';
import { IFlightLinked } from '../IFlightLiked';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-flights',
  templateUrl: './view-flights.component.html',
  styleUrls: ['./view-flights.component.css']
})
export class ViewFlightsComponent implements OnInit {

  FlightData : IFlightLinked[]=[];
  constructor(private LoginService:AdminLoginService, private router:Router) { }

  ngOnInit() {
    this.LoginService.GetAllFlights().subscribe((data:any) =>
    {
      this.FlightData=data;
      

    });
  }
  onEdit(flightId:number){
    this.router.navigate(["editFlight", flightId])
  }

}
