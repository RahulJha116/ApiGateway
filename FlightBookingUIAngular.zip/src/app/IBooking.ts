export interface IBooking{
    bookingId: number;
    flightNumber :string;
    pnr  : string;
    passengerDetail:string;
    meal:string
    businessClass  :boolean;
    numberOfSeats  :number;
    seatNumbers  :number;
    priceOfTicket  :number;
    userEmailId :string;
    startDateTime  :Date; 
    endDateTime  :Date;
    fromPlace : string;
    toPlace  :string;
    discountCode:string;
}