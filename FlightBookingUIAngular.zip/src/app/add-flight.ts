export class AddFlight {
    FromPlace : string;
    ToPlace  :string;
    StartDateTime  :Date; 
    EndDateTime  :Date;
    FlightNumber :string;
    ScheduleDayOfWeek  : string;
    NoOfBusinessClassSeat  :number;
    NoOfNonBusinessClassSeat  :number;
    FlightBusinessClassTicketPrice  :number;
    FlightNonBusinessClassTicketPrice  :number;
    Meal :string;
    airlineId :number;

    constructor(){
        this.FromPlace="";
        this.ToPlace="";
        this.StartDateTime=new Date('dd/Mm/yyyy hh:mm:ss');
        this.EndDateTime=new Date('dd/Mm/yyyy hh:mm:ss');
        this.FlightNumber="";
        this.ScheduleDayOfWeek="";
        this.NoOfBusinessClassSeat=0;
        this.NoOfNonBusinessClassSeat=0;
        this.FlightBusinessClassTicketPrice=0;
        this.FlightNonBusinessClassTicketPrice=0;
        this.Meal="";
        this.airlineId=0;


    }


    
}
