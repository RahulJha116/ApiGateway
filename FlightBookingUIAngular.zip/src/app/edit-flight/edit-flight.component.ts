import { Component, OnInit } from '@angular/core';
import { AdminLoginService } from '../adminlogin.service';    
import { AddFlight } from '../add-flight';  
import { Router, ActivatedRoute } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
import { IFlightLinked } from '../IFlightLiked';

@Component({
  selector: 'app-edit-flight',
  templateUrl: './edit-flight.component.html',
  styleUrls: ['./edit-flight.component.css']
})
export class EditFlightComponent implements OnInit {

  data = false;    
  submitted = false;
  AddFlightForm: any;    
  massage:string;    
  constructor(private formbulider: FormBuilder,private loginService:AdminLoginService,private router:Router,private ar:ActivatedRoute) {
    this.massage = "";
   }    
    
  ngOnInit():void {    
    this.ar.params.subscribe(params =>{
      let flightId = params["id"];
      console.log(flightId);
      this.loginService.GetAllFlightbyid(flightId).toPromise().then(res=>{
      this.AddFlightForm = this.formbulider.group({  
      FlightID: [res.flightId,Validators.required]  , 
      FromPlace: [res.fromPlace, [Validators.required]],    
      ToPlace: [res.toPlace, [Validators.required]],  
      StartDateTime:  [res.startDateTime, [Validators.required]] , 
      EndDateTime:[res.endDateTime, [Validators.required]], 
      FlightNumber: [res.flightNumber, [Validators.required,  Validators.maxLength(8)]],         
      ScheduleDayOfWeek: [res.scheduleDayOfWeek, [Validators.required]], 
      NoOfBusinessClassSeat:[res.noOfBusinessClassSeat, [Validators.required]], 
      NoOfNonBusinessClassSeat:[res.noOfNonBusinessClassSeat, [Validators.required]], 
      FlightBusinessClassTicketPrice:[res.flightBusinessClassTicketPrice, [Validators.required]], 
      FlightNonBusinessClassTicketPrice:[res.flightBusinessClassTicketPrice, [Validators.required]], 
      Meal:[res.meal, [Validators.required]], 
      airlineId:[res.airlineId, [Validators.required]], });

    })}) 
  }    
  get f() {return this.AddFlightForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;


    const flight = this.AddFlightForm.value;    
    this.UpdateFlight(flight);    
  }    
  onreset(){
    
    this.AddFlightForm.reset();}

  UpdateFlight(flight:IFlightLinked)   
  {    
  this.loginService.updateFlight(flight).subscribe()
    {
      this.data=true;
      alert("Flight updated !!!")
      this.router.navigate(['/viewflight']); 

      
    }  
  }
  
  

  
}


