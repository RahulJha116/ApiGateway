
export class User {

    userId:number;
    userName:string;
    constructor(){
        this.userId=0
        this.userName="";
    }
}