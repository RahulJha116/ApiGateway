export interface IViewairline{
    airlineId:number;
    airlineName:string;
    airlineContactNumber:number;
    airlineAddress:string;
    airlineLogo:string;
}