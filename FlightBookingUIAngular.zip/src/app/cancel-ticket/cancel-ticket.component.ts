import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { IBooking } from '../IBooking';

import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
import { PNR } from 'src/PNR';

@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {

  
  a:any;
  data = false;    
  submitted = false;
  Cancelform: any;    
  
  BookingData: IBooking[] = [];
  massage:string; 
  constructor(private formbulider: FormBuilder,private loginService:LoginService,
    private router:Router) { 
      this.massage = "";
    }

  ngOnInit() {    
    this.Cancelform = this.formbulider.group({    
      PNR: ['', [Validators.required]],
     

    });  
    
  }    

  get f() {return this.Cancelform.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const pnr = this.Cancelform.value;    
    this.TicketCancel(pnr);  
  }    
  onreset(){
    
    this.Cancelform.reset();}

    TicketCancel(pnr:PNR)   
  {    
  this.loginService.TicketCancel(pnr).subscribe(
    data=>{
      this.a=data;
      alert(this.a)
    }  
       
  )}

  
}  
