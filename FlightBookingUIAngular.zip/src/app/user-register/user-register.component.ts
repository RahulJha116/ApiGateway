import { Component, OnInit } from '@angular/core';    
import { LoginService } from '../login.service';    
import {Register} from '../register';    
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, Validators, FormControl } from '@angular/forms'; 

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent implements OnInit {

  data = false;    
  submitted = false;
  UserForm: any;    
  massage:string;    
  constructor(private formbulider: FormBuilder,private loginService:LoginService,private router:Router) {
    this.massage = "";
   }    
    
  ngOnInit() {    
    this.UserForm = this.formbulider.group({    
      UserName: ['', [Validators.required, Validators.minLength(3)]],    
      Age: ['', [Validators.required]],    
      Passkey: ['', [Validators.required, Validators.minLength(8)]],    
      EmailId: ['', [Validators.required, Validators.email]],      
      Address: ['', [Validators.required]]
    });    
  }    

  get f() {return this.UserForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const user = this.UserForm.value;    
    this.Createuser(user);    
  }    
  onreset(){
    
    this.UserForm.reset();}

  Createuser(register:Register)    
  {    
  this.loginService.CreateUser(register).subscribe( 
    data=>{
      this.massage=data;
      console.log(this.massage)
      this.data = true;    
      alert(this.massage);

      //this.massage = 'Data saved Successfully'; 
      this.router.navigate(['/login']);   
      //this.UserForm.reset();    
    });    
  }    
}    
