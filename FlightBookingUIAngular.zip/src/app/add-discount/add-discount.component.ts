import { Component, OnInit } from '@angular/core';
import { AdminLoginService } from '../adminlogin.service';    
import {Discount} from '../Discount';    
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 

@Component({
  selector: 'app-add-discount',
  templateUrl: './add-discount.component.html',
  styleUrls: ['./add-discount.component.css']
})
export class AddDiscountComponent implements OnInit {

  
  data = false;    
  submitted = false;
  AddDiscountForm: any;    
  massage:string;    
  constructor(private formbulider: FormBuilder,private loginService:AdminLoginService,private router:Router) {
    this.massage = "";
   }    
    
  ngOnInit() {    
    this.AddDiscountForm = this.formbulider.group({    
      DiscountCode: ['', [Validators.required]],    
      DiscountAmount: ['', [Validators.required]],    
    });    
  }    

  get f() {return this.AddDiscountForm.controls;}

   onFormSubmit()    
  {    
    this.submitted=true;

    const airline = this.AddDiscountForm.value;    
    this.AddAirline(airline);    
  }    
  onreset(){
    
    this.AddDiscountForm.reset();}

  AddAirline(discount:Discount)    
  {    
  this.loginService.AddDiscount(discount).subscribe(    
    ()=>    
    {    
      this.data = true;    
      //this.massage = 'Data saved Successfully'; 
      alert("Discount Added !!!")
      this.router.navigate(['/AdminDashboard']);   
      this.AddDiscountForm.reset();    
    });    
  }    
}  
