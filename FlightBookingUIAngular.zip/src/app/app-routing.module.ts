import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserLoginComponent } from './user-login/user-login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchPNRComponent } from './search-pnr/search-pnr.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { SearchFlightOneway } from './search-flight-oneway';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { SearchBookingByEmailComponent } from './search-booking-by-email/search-booking-by-email.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { AdminLoginService } from './adminlogin.service';
import { AdminloginComponent } from './adminlogin/adminlogin.component'; 
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AddFlightComponent } from './add-flight/add-flight.component';
import { AddDiscountComponent } from './add-discount/add-discount.component';
import { BookingFlight } from 'src/BookingFlight';
import { AddAirlineComponent } from './add-airline/add-airline.component';
import { ViewDiscountComponent } from './view-discount/view-discount.component';
import { ViewAirlineComponent } from './view-airline/view-airline.component';
import { EditDiscountComponent } from './edit-discount/edit-discount.component';
import { BookFlightComponent } from './book-flight/book-flight.component';
import { SearchFlightRoundwayComponent } from './search-flight-roundway/search-flight-roundway.component';
import { ViewFlightsComponent } from './view-flights/view-flights.component';
import { EditFlightComponent } from './edit-flight/edit-flight.component';
export const routes: Routes = [    
  {    
    path: '',    
    redirectTo: 'localhost',    
    pathMatch: 'full',    
  },    
  {    
    path: 'login',    
    component: UserLoginComponent,    
    data: {    
      title: 'Login Page'    
    }   
  },
  {    
    path: 'AddUser',    
    component: UserRegisterComponent,    
    data: {    
      title: 'Add User Page'    
    }    
  },  
  {
  path: 'Dashboard',    
  component: DashboardComponent,    
  data: {    
    title: 'Dashboard Page'    
  } 

  },
  {    
    path: 'adminlogin',    
    component: AdminloginComponent,    
    data: {    
      title: 'Admin Login Page'    
    }    
  },    
  {    
    path: 'logout',    
    component: AdminDashboardComponent,    
    data: {    
      title: 'Admin logout Page'    
    }    
  },  
  {
    path: 'AdminDashboard',    
    component: AdminDashboardComponent
    
    ,    
    data: {    
      title: 'Dashboard Page'    
    } 
    
    }, 
    {    
      path: 'AddFlight',    
      component: AddFlightComponent,    
      data: {    
        title: 'Add Flight Page'    
      }    
    },
    {    
      path: 'AddAirline',    
      component: AddAirlineComponent,    
      data: {    
        title: 'Add Airline Page'    
      }    
    },  
  {    
    path: 'searchPNR',    
    component: SearchPNRComponent,    
    data: {    
      title: 'Search PNR '    
    }    
  },
  {    
    path: 'OneWay',    
    component: SearchFlightComponent,    
    data: {    
      title: 'Search OneWay Flight'    
    }    
  },
  {    
    path: 'roundWay',    
    component: SearchFlightRoundwayComponent,    
    data: {    
      title: 'Search roundWay Flight'    
    }    
  },
  {    
    path: 'adddiscount',    
    component: AddDiscountComponent,    
    data: {    
      title: 'Add Discount'    
    }    
  },
  {    
    path: 'bookingHistory',    
    component: SearchBookingByEmailComponent,    
    data: {    
      title: 'View Bookings '    
    }    
  },
  {    
    path: 'ticketCancel',    
    component: CancelTicketComponent,    
    data: {    
      title: 'Cancel Ticket'    
    }    
  },
  {    
    path: 'viewdiscount',    
    component: ViewDiscountComponent,    
    data: {    
      title: 'View Discount'    
    }    
  },
  {    
    path: 'viewflight',    
    component: ViewFlightsComponent,    
    data: {    
      title: 'View Discount'    
    }    
  },
  {    
    path: 'getAllAirline',    
    component: ViewAirlineComponent,    
    data: {    
      title: 'View Ailrine '    
    }    
  },
  {    
    path: 'editDiscount/:id',    
    component: EditDiscountComponent,    
    data: {    
      title: 'View Discount'    
    }    
  },
  {    
    path: 'editFlight/:id',    
    component: EditFlightComponent,    
    data: {    
      title: 'View Flight'    
    }    
  },
  {    
    path: 'booked/:id',    
    component: BookFlightComponent,    
    data: {    
      title: 'BookFlight'    
    }    
  },
  {    
    path: 'bookingFlight',    
    component: BookFlightComponent,    
    data: {    
      title: 'BookFlight'    
    }    
  },
]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
