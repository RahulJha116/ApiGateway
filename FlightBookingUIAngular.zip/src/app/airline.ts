export class Airline {
    airlineName:string;
    airlineContactNumber:number;
    airlineAddress:string;
    airlineLogo:string;

    constructor(){
        this.airlineName="";
        this.airlineContactNumber=0;
        this.airlineAddress="";
        this.airlineLogo="";

    }

}
