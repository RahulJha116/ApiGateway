import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';  
import {HttpHeaders} from '@angular/common/http';  
import { HttpErrorResponse} from '@angular/common/http';
import {  BehaviorSubject, from, Observable, observable, throwError } from 'rxjs'; 
import { map, catchError,tap } from 'rxjs/operators'; 
import { Airline } from './airline';
import { AddFlight } from './add-flight';
import { Router } from '@angular/router';  
import { Discount } from './Discount';
import { IDiscount } from './IDiscount';
import { IFlightLinked } from './IFlightLiked';

@Injectable({
  providedIn: 'root'
})
export class AdminLoginService {  
  //token : string;  
  Url: any;
  header : any;  
  constructor(private http : HttpClient, private Router:Router) {   
  

    this.Url = 'http://localhost:59349/';  
  }
  
  Login(EmailId: string, Passkey: string){  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post(this.Url+'Airline/Adminlogin?'+'adminEmailId='+EmailId + '&adminPasskey='+Passkey,httpOptions);
    

    
    
  }  

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('usertoken');
  }

  GetAllDiscountbyid(discountid:number):Observable<any>
  {
   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   return this.http.get(this.Url + 'Discount/'+discountid,  httpOptions)
  }
  GetAllFlightbyid(flightId:number):Observable<any>
  {
   const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
   return this.http.get(this.Url + 'Flight/'+flightId,  httpOptions)
  }
  AddDiscount(discount:Discount)  
   { 
      let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
      
    return this.http.post<Discount>(this.Url + 'Discount/AddDiscount', discount,  {headers:header})  
   } 
  DeleteDiscount(discountId:number)
  {
    let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
     
   return this.http.delete(this.Url + 'Discount/DeleteDiscount?id=' + discountId,  {headers:header})
  }
  updateDiscount(discount:IDiscount)
 {
    let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
     
   return this.http.put<string>(this.Url + 'Discount/updateDiscount', discount,  {headers:header}) 
 }
 updateFlight(flight:IFlightLinked)
 {
    let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
     
   return this.http.put<string>(this.Url + 'Flight/updateFlight', flight,  {headers:header}) 
 }
 GetAllDiscount()
 {
    let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
    
  return this.http.get(this.Url + 'Discount',  {headers:header})

 }
 BlockAirline(airlineId:number)
 {
  let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
      
  return this.http.post(this.Url + 'Flight/BlockFlight?airlineid=' + airlineId,  {headers:header})

 }
 UnBlockAirline(airlineId:number)
 {
   let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
      
  return this.http.post(this.Url + 'Flight/UnBlockFlight?airlineid=' + airlineId,  {headers:header})

 }
 GetAllAirline()
 {
  let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
      
  return this.http.get(this.Url + 'Airline',  {headers:header})
 }
 GetAllFlights()
 {
  let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
      
  return this.http.get(this.Url + 'Flight',  {headers:header})
 }
 ViewRelatedFlights(airlineId:number)
 {
   
  let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
     
  return this.http.get(this.Url + 'Flight/GetFlightByAirlineId?airlineid=' + airlineId,  {headers:header})
 }
 AddAirline(airline:Airline)  
  {let header = new HttpHeaders().set("Content-Type", "application/json").set("Authorization", "Bearer "+ localStorage.getItem("usertoken"));
      
    return this.http.post<Airline>(this.Url + 'Airline/register', airline, {headers:header})  ;
   }  
   AddFlight(flight:AddFlight)  
   {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };  
    return this.http.post<AddFlight>(this.Url + 'Flight/Add', flight, httpOptions)  
   } 
}

