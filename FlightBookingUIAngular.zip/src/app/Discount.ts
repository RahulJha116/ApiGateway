export class Discount {
    DiscountCode:string;
    DiscountAmount:number;

    constructor(){
        this.DiscountCode="";
        this.DiscountAmount=0;

    }

}