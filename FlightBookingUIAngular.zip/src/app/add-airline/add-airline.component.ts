import { Component, OnInit } from '@angular/core';
import { AdminLoginService } from '../adminlogin.service';    
import {Airline} from '../airline';    
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 

@Component({
  selector: 'app-add-airline',
  templateUrl: './add-airline.component.html',
  styleUrls: ['./add-airline.component.css']
})
export class AddAirlineComponent implements OnInit {

  data = false;    
  submitted = false;
  AddAirlineForm: any;    
  massage:string;    
  constructor(private formbulider: FormBuilder,private loginService:AdminLoginService,private router:Router) {
    this.massage = "";
   }    
    
  ngOnInit() {    
    this.AddAirlineForm = this.formbulider.group({    
      airlineName: ['', [Validators.required, Validators.minLength(5)]],    
      airlineContactNumber: ['', [Validators.required,  Validators.minLength(10), Validators.maxLength(10)]],    
      airlineAddress: ['', [Validators.required]],         
      airlineLogo: ['', [Validators.required]],    
    });    
  }    

  get f() {return this.AddAirlineForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const airline = this.AddAirlineForm.value;    
    this.AddAirline(airline);    
  }    
  onreset(){
    
    this.AddAirlineForm.reset();}

  AddAirline(airline:Airline)    
  {    
  this.loginService.AddAirline(airline).subscribe(    
    ()=>    
    {    
      this.data = true;    
      //this.massage = 'Data saved Successfully'; 
      alert("Airline Added !!!")
      this.router.navigate(['/AdminDashboard']);   
      this.AddAirlineForm.reset();    
    });    
  }    
}  
