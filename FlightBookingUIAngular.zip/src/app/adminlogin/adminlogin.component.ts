import { Component, OnInit } from '@angular/core';    
import { Router ,ActivatedRoute} from '@angular/router';    
import { AdminLoginService } from '../adminlogin.service'   
import { FormsModule, FormBuilder, Validators } from '@angular/forms'; 
@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  loginForm: any;
  submitClick = false;
  submitted = false;
  returnUrl: string;
  error = '';
  
   constructor(private formBuilder: FormBuilder,private router:Router,private LoginService:AdminLoginService, private route: ActivatedRoute) {
     this.returnUrl = "";
    }    
     
     
    ngOnInit() {
     this.loginForm = this.formBuilder.group({
     EmailId: ['', Validators.required],
     password: ['', Validators.required]
     });
    
     this.LoginService.logout();
    
     this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
     }
    
     get formData() { return this.loginForm.controls; }
    
     onLogin() {
     this.submitted = true;
    
     if (this.loginForm.invalid) {
     return;
     }
    
     this.submitClick = true;
     this.LoginService.Login(this.formData.EmailId.value, this.formData.password.value)
     .subscribe(z=>{
       console.log(z);
       localStorage.setItem('usertoken',z.toString());
 
       if(z!=null)
       {
         alert("logged in sucessfully")
       this.router.navigate(['/AdminDashboard']);  
       }})
 
 
     
     }
    }
       