import { Component, OnInit } from '@angular/core';
import { IBooking } from '../IBooking';
import { LoginService } from '../login.service';    
import { Router } from '@angular/router';    
import {Observable} from 'rxjs';    
import { NgForm, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms'; 
import { PNR } from 'src/PNR';
import 'jspdf-autotable'
import jsPDF from 'jspdf';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-search-pnr',
  templateUrl: './search-pnr.component.html',
  styleUrls: ['./search-pnr.component.css']
})
export class SearchPNRComponent implements OnInit {

  data = false;    
  submitted = false;
  SearchPNRForm: any;    
  
  BookingData: IBooking[] = [];
  massage:string; 
  rows:any;

  head =[['Booking Id', 'Flight Number', 'UserEmailId','PriceOfTicket','PNR', 'PassengerDetail'
,'Meal','BusinessClass','NumberOfSeats','SeatNumbers','FromPlace','ToPlace','StartDateTime','EndDateTime']];
  constructor(private formbulider: FormBuilder,private loginService:LoginService,
    private router:Router) {
    this.massage = "";
   };
    
  ngOnInit() {    
    this.SearchPNRForm = this.formbulider.group({    
      PNR: ['', [Validators.required]],
     

    });  
    
  }    

  get f() {return this.SearchPNRForm.controls;}
   onFormSubmit()    
  {    
    this.submitted=true;

    const pnr = this.SearchPNRForm.value;    
    this.SearchPNRMethod(pnr);    
  }    
  onreset(){
    
    this.SearchPNRForm.reset();}


    ondownload(data:any):void{
      var doc=new jsPDF();
      doc.setFontSize(18);
      doc.text('Booking Details',11,8);
      doc.setFontSize(11);
      doc.setTextColor(100);

      this.rows = [[data.bookingId,data.flightNumber,data.userEmailId,data.priceOfTicket,data.pnr,
        data.passengerDetail,data.meal,data.businessClass,data.numberOfSeats,data.seatNumbers,data.fromPlace,data.toPlace,
      data.startDateTime,data.endDateTime]];

      (doc as any).autoTable({
        head:this.head,
        body:this.rows,
        theme: 'grid',
        statrtY: 150,
        margin: {horizontal: 10},
        pageBreak: 'auto',
        tableWidth: 'grid',
        columnStyles:{
                0:{cellwidth: 25, },
                1:{cellwidth: 25, },
                2:{cellwidth: 25, },
                3:{cellwidth: 25, },
                4:{cellwidth: 25, },
                5:{cellwidth: 25, },
                6:{cellwidth: 25, },
                7:{cellwidth: 25, },
                8:{cellwidth: 25, },
                9:{cellwidth: 25, },
                10:{cellwidth: 25, },
                11:{cellwidth: 25, },
                12:{cellwidth: 25, },
                13:{cellwidth: 25, },
              },
        styles:{minCellHeight: 53},
      didDrawCell:( rows:{column:{ index:any;};}) => {
        console.log(rows.column.index)
      }


      })

      doc.output('dataurlnewwindow')

    }

  SearchPNRMethod(pnr:PNR)   
  {    
  this.loginService.Searchpnr(pnr).subscribe(
    data=>{
      this.BookingData=data;
      alert(JSON.stringify(this.BookingData))
    }  
       
  )}
}  
