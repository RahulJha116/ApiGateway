import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFlightRoundwayComponent } from './search-flight-roundway.component';

describe('SearchFlightRoundwayComponent', () => {
  let component: SearchFlightRoundwayComponent;
  let fixture: ComponentFixture<SearchFlightRoundwayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchFlightRoundwayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFlightRoundwayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
