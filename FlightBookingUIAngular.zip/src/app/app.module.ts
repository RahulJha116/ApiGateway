import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { UserLoginComponent } from './user-login/user-login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EditDiscountComponent } from './edit-discount/edit-discount.component';
import { SearchPNRComponent } from './search-pnr/search-pnr.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { SearchBookingByEmailComponent } from './search-booking-by-email/search-booking-by-email.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component'
import { AddFlightComponent } from './add-flight/add-flight.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AddDiscountComponent } from './add-discount/add-discount.component';
import { AddAirlineComponent } from './add-airline/add-airline.component';
import { ViewDiscountComponent } from './view-discount/view-discount.component';
import { ViewAirlineComponent } from './view-airline/view-airline.component';
import { BookFlightComponent } from './book-flight/book-flight.component';
import { SearchFlightRoundwayComponent } from './search-flight-roundway/search-flight-roundway.component';
import { ViewFlightsComponent } from './view-flights/view-flights.component';
import { EditFlightComponent } from './edit-flight/edit-flight.component';

@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    AdminDashboardComponent,
    DashboardComponent,
    SearchPNRComponent,
    UserRegisterComponent,
    SearchFlightComponent,
    SearchBookingByEmailComponent,
    CancelTicketComponent,
    AdminloginComponent,
    AddDiscountComponent,
    AddAirlineComponent,
    BookFlightComponent,
    AddFlightComponent,
    EditDiscountComponent,
    ViewDiscountComponent,
    ViewAirlineComponent,
    SearchFlightRoundwayComponent,
    ViewFlightsComponent,
    EditFlightComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
