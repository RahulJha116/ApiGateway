export class SearchFlightRoundway {
    fromPlace : string;
    toPlace  :string;
    flightDate  :Date; 
    returnFlightDate : Date;

    constructor(){
        this.fromPlace="";
        this.toPlace="";
        this.flightDate=new Date('dd/M/yyyy hh:mm:ss');
        this.returnFlightDate=new Date('dd/M/yyyy hh:mm:ss')
    }
}