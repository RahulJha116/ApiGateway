export class BookingFlight {
    flightNumber :string;
    passengerDetail:string;
    meal:string
    businessClass  :boolean;
    numberOfSeats  :number;
    seatNumbers  :number;
    priceOfTicket  :number;
    userEmailId :string;
    startDateTime:Date;
    endDateTime:Date;
    fromPlace:string;
    toPlace:string;
    discountCode:string;


    constructor(){
        this.flightNumber="";
        this.passengerDetail=""
        this.meal=""
        this.businessClass=false;
        this.numberOfSeats=0;
        this.seatNumbers=0;
        this.priceOfTicket=0;
        this.userEmailId="";
        this.startDateTime= new Date('dd/M/yyyy hh:mm:ss');
        this.endDateTime=new Date('dd/M/yyyy hh:mm:ss');
        this.fromPlace="";
        this.toPlace="";
        this.discountCode="";





    }

}