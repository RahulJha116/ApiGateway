export class PNR {
    PNR : string;
    

    constructor(){
        this.PNR="";
    }
}